from django.contrib import admin
from django.urls import path,include


from s_survey import views

#
urlpatterns = [

    path('',views.surveyList,name='surveyList'),
    path('addSurvey', views.addSurvey, name='addSurvey'),
    path('addSurveySubmit',views.addSurveySubmit,name='addSurveySubmit'),
    path('updateSurvey/<int:id>/',views.updateSurvey,name='updateSurvey'),
    path('assignSuveyCustomer/<int:id>/',views.assignSuveyCustomer,name='assignSuveyCustomer'),
    path('subUpdateSurvey/<int:id>/',
         views.subUpdateSurvey, name='subUpdateSurvey'),
    path('deleteSurvey/<int:id>/',
         views.deleteSurvey, name='deleteSurvey'),
    # path('updateSurveyType/',views.updateSurveyType,name='updateSurveyType'),
    path('survey_question/<int:id>/', views.survey_question_view, name='survey_question'),
    path('deleteAssigned/<int:id>/', views.deleteAssigned, name='deleteAssigned'),
     path('moveSelectedCustomers/<int:survey_id>/', views.moveSelectedCustomers, name='moveSelectedCustomers'),
# path('assign-survey-customer/<int:id>/', views.assignSurveyCustomer, name='assignSurveyCustomer'),
]

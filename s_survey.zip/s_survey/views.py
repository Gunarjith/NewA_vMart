from django.http import HttpResponse
from django.shortcuts import render,redirect
from vailodb_s.models import Survey_list, Survey_Question, Survey_Customer, Survey_Question_Map
from django.http import JsonResponse
import json
from django.db import transaction, IntegrityError
from django.http import JsonResponse
from django.core.exceptions import ObjectDoesNotExist
from django.contrib import messages
from django.contrib.auth.decorators import login_required

def surveyList(request):
    listsurvey = Survey_list.objects.filter(client_id=request.user.id)
    context = {
        'listsurvey': listsurvey, 
    }

    return render(request, 's_survey/surveyList.html', context)

def addSurvey(request):
  
    return render(request, 's_survey/addSurvey.html')

def addSurveySubmit(request):
    if request.method == 'POST':
        # Create a new Survey_list instance
        submitAddsurvey = Survey_list()
        
        if 'surveyImg' in request.FILES:
            submitAddsurvey.survey_image = request.FILES['surveyImg']

        submitAddsurvey.survey_message = request.POST.get('surveyMessageText')
        submitAddsurvey.survey_footer = request.POST.get('surveyFooter')
        submitAddsurvey.survey_type = request.POST.get('surveyType')
        
        if 'surveyStatus' in request.POST:
            submitAddsurvey.survey_status = request.POST.get('surveyStatus')

        submitAddsurvey.client = request.user  # Set the client to the current user
        submitAddsurvey.save()

        return redirect("surveyList")
    
    return render(request, 's_survey/surveyList.html')
def updateSurvey(request, id):
 
    updateSurvey = Survey_list.objects.filter(
        client_id=request.user.id, id=id)
    
    context ={
        "updateSurvey": updateSurvey,
        
    }
    return render(request, 's_survey/editSurvey.html', context)


def subUpdateSurvey(request, id):
    subUpdateSurvey = Survey_list.objects.filter(
        client_id=request.user.id, id=id)
    if request.method == 'POST':
        for i in subUpdateSurvey:
            # Update the campaign fields based on the form data
            editinfo = Survey_list.objects.get(id=i.id)
            if request.POST.get('resurveyMessageText'):
                editinfo.survey_message = request.POST.get('resurveyMessageText')
            if request.POST.get('resurveyFooter'):
                editinfo.survey_footer = request.POST.get(
                    'resurveyFooter')
            if request.POST.get('resurveyType'):
                editinfo.survey_type = request.POST.get(
                    'resurveyType')
            
           
           
            survey_status = request.POST.get('reSurveyStatus')
            if survey_status is not None and survey_status != '':
                editinfo.survey_status = int(survey_status)

            # Update the campaign header image if provided
            if 'reresurvey_image' in request.FILES and len(request.FILES['reresurvey_image']) != 0:
                editinfo.survey_image = request.FILES['reresurvey_image']

            editinfo.save()

        return redirect('surveyList')

    # When the request method is not POST, render the form with the existing campaign data
    return render(request, 's_survey/editSurvey.html', {'updateCampaign': subUpdateBCamaign})

def deleteSurvey(request,id):
    deleteSurvey = Survey_list.objects.get(
        client_id=request.user.id, pk=id)
    deleteSurvey.delete()
    return redirect('surveyList')


# def updateSurveyType(request):
#     updateSurveyType = Survey_list.objects.filter(
#         client_id=request.user.id)
#     if request.method == 'POST':
#         for i in updateSurveyType:
#             # Update the campaign fields based on the form data
#             editinfo = Survey_list.objects.get(id=i.id)
          
#             if request.POST.get('updateSurveyType'):
#                 editinfo.survey_type = request.POST.get(
#                     'updateSurveyType')
        
#             editinfo.save()

#         return redirect('surveyList')

#     # When the request method is not POST, render the form with the existing campaign data
#     return render(request, 's_survey/survey_question.html',{'updateSurveyType':updateSurveyType})

# def survey_question_view(request, id):
#     # Retrieve the specific Survey_list object
#     surveyType = Survey_list.objects.get(client_id=request.user.id, id=id)

#     try:
#         # Try to retrieve an existing Survey_Question object
#         detailSurvey = Survey_Question.objects.get(client_id=request.user.id, id=id)
#     except Survey_Question.DoesNotExist:
#         # If it doesn't exist, create a new one
#         detailSurvey, created = Survey_Question.objects.get_or_create(
#             client=request.user,
#             id=id,
#             defaults={
#                 'question': request.POST.get('question'),
#                 'response_option1': request.POST.get('response_option1'),
#                 'response_option2': request.POST.get('response_option2'),
#                 'response_option3': request.POST.get('response_option3'),
#                 'response_option4': request.POST.get('response_option4'),
#                 # Other fields here
#             }
#         )

#     if request.method == 'POST':
#         # Update the survey details based on the form data
#         detailSurvey.question = request.POST.get('question')
#         detailSurvey.response_option1 = request.POST.get('response_option1')
#         detailSurvey.response_option2 = request.POST.get('response_option2')
#         detailSurvey.response_option3 = request.POST.get('response_option3')
#         detailSurvey.response_option4 = request.POST.get('response_option4')
#         # Update other fields as needed
#         detailSurvey.save()

#         # Update the survey_type for the specific Survey_list object
#         surveyType.survey_type = request.POST.get('updateSurveyType')
#         surveyType.save()

#     # Rest of your view logic here

#     return render(request, 's_survey/survey_question.html', {'detailSurvey': detailSurvey, 'surveyType': surveyType})
def survey_question_view(request, id):
    # Retrieve the specific Survey_list object
    surveyType = Survey_list.objects.get(client_id=request.user.id, id=id)

    try:
        # Try to retrieve an existing Survey_Question object
        detailSurvey = Survey_Question.objects.get(client_id=request.user.id, id=id)
    except Survey_Question.DoesNotExist:
        # If it doesn't exist, create a new one
        detailSurvey, created = Survey_Question.objects.get_or_create(
            client=request.user,
            id=id,
            defaults={
                'question': request.POST.get('question', ''),  # Provide an empty string
                'response_option1': request.POST.get('response_option1', ''),
                'response_option2': request.POST.get('response_option2', ''),
                'response_option3': request.POST.get('response_option3', ''),
                'response_option4': request.POST.get('response_option4', ''),
                'question_type': request.POST.get('question_type', ''),
                # Other fields here
            }
        )

    if request.method == 'POST':
        if 'submitQuestionOptions' in request.POST:
            # Handle the form data from the survey_question form
            detailSurvey.question = request.POST.get('question', '')  # Provide an empty string
            detailSurvey.response_option1 = request.POST.get('response_option1', '')
            detailSurvey.response_option2 = request.POST.get('response_option2', '')
            detailSurvey.response_option3 = request.POST.get('response_option3', '')
            detailSurvey.response_option4 = request.POST.get('response_option4', '')
            detailSurvey.question_type = request.POST.get('question_type', '')
            # Update other fields as needed
            detailSurvey.save()
        elif 'submitSurveyType' in request.POST:
            # Update the survey_type for the specific Survey_list object
            surveyType.survey_type = request.POST.get('updateSurveyType')
            surveyType.save()

    # Rest of your view logic here

    return render(request, 's_survey/survey_question.html', {'detailSurvey': detailSurvey, 'surveyType': surveyType})

def assignSuveyCustomer(request, id):
    surveyType = Survey_list.objects.get(client_id=request.user.id, id=id)
    assignCustomer = Survey_Customer.objects.filter(
        client_id=request.user.id)
    selectedCustomer = list(Survey_Question_Map.objects.filter(
        client_id=request.user.id, Survey_list_id=id))

    # Debugging: Print selectedCustomer to check its content
    print(selectedCustomer)

    return render(request, 's_survey/survey_assignn.html', {
        'assignCustomer': assignCustomer,
        'surveyType': surveyType,
        'selectedCustomer': selectedCustomer
    })
 
@transaction.atomic
def moveSelectedCustomers(request, survey_id):
    if request.method == 'POST':
        selected_customer_ids = request.POST.getlist('selected_customer_ids')
        print('selected_customer_ids',selected_customer_ids)
        if not selected_customer_ids:
            return JsonResponse({'success': False, 'message': 'No customers selected.'})

        try:
            with transaction.atomic():
                survey = Survey_list.objects.get(client=request.user, id=survey_id)
                duplicate_entries = []  # List to store duplicate entry messages

                for customer_id in selected_customer_ids:
                    customer = Survey_Customer.objects.get(client=request.user, id=customer_id)

                    try:
                        # Check for duplicates
                        existing_mapping = Survey_Question_Map.objects.get(
                            client=request.user, Survey_list=survey, Survey_Customer=customer)

                        duplicate_entries.append(f"Duplicate entry: Customer '{customer.customer_name}' is already assigned to this survey.")
                    except Survey_Question_Map.DoesNotExist:
                        try:
                            Survey_Question_Map.objects.create(
                                client=request.user,
                                Survey_list=survey,
                                Survey_Customer=customer
                            )
                        except IntegrityError:
                            # Handle other errors if necessary
                            pass

                if duplicate_entries:
                    # Notify duplicates and skip them
                    messages.error(request, "Duplicate entries: Some customers were already assigned and skipped.")
                else:
                    # Notify success
                    messages.success(request, "Customers assigned successfully.")

                return redirect('assignSuveyCustomer', id=survey_id)

        except Exception as e:
            return JsonResponse({'success': False, 'message': str(e)})

    return JsonResponse({'success': False, 'message': 'Invalid request method.'})  
   
def deleteAssigned(request,id):
    deleteAssigned = Survey_Question_Map.objects.get(
        client_id=request.user.id, pk=id)
    generic_campaign_info_id = deleteAssigned.Survey_list_id
    deleteAssigned.delete()
    return redirect('assignSuveyCustomer',id=generic_campaign_info_id)

# def moveSelectedCustomers(request, survey_id):
#     if request.method == 'POST':
#         data = request.POST  # You may need to adjust this based on your frontend
#         selected_customer_ids = data.getlist('selected_customer_ids')  # Assuming you have checkboxes with name 'selected_customer_ids'

#         # Check if there are selected customers
#         if not selected_customer_ids:
#             return JsonResponse({'success': False, 'message': 'No customers selected.'})

#         try:
#             # Get the survey instance
#             survey = Survey_list.objects.get(client=request.user, id=survey_id)

#             # Loop through the selected customer IDs
#             for customer_id in selected_customer_ids:
#                 customer = Survey_Customer.objects.get(client=request.user, id=customer_id)

#                 # Create a new customer mapping entry
#                 Survey_Question_Map.objects.create(
#                     client=request.user,
#                     Survey_list=survey,
#                     Survey_Customer=customer
#                 )

#             return JsonResponse({'success': True, 'message': 'Customers assigned successfully.'})
#         except Exception as e:
#             return JsonResponse({'success': False, 'message': str(e)})

#     return JsonResponse({'success': False, 'message': 'Invalid request method.'})

# def survey_question_view(request, id):
#     try:
#         # Try to retrieve an existing Survey_Question object
#         surveyType = Survey_list.objects.filter(
#         client_id=request.user.id, id=id)
#         detailSurvey = Survey_Question.objects.get(client_id=request.user.id, id=id)
#     except Survey_Question.DoesNotExist:
#         # If it doesn't exist, create a new one
#         detailSurvey, created = Survey_Question.objects.get_or_create(
#             client=request.user,
#             id=id,
#             defaults={
#                 'question': request.POST.get('question'),
#                 'response_option1': request.POST.get('response_option1'),
#                 'response_option2': request.POST.get('response_option2'),
#                 'response_option3': request.POST.get('response_option3'),
#                 'response_option4': request.POST.get('response_option4'),
#                 # Other fields here
#             }
#         )

#     if request.method == 'POST':
#         # Update the survey details based on the form data
#         detailSurvey.question = request.POST.get('question')
#         detailSurvey.response_option1 = request.POST.get('response_option1')
#         detailSurvey.response_option2 = request.POST.get('response_option2')
#         detailSurvey.response_option3 = request.POST.get('response_option3')
#         detailSurvey.response_option4 = request.POST.get('response_option4')
#         # Update other fields as needed
#         detailSurvey.save()

#     # Rest of your view logic here

#     return render(request, 's_survey/survey_question.html', {'detailSurvey': detailSurvey, 'surveyType': surveyType})




# def survey_question_view(request, id):
#     detailSurvey = Survey_Question.objects.get(client_id=request.user.id, id=id)

#     if request.method == 'POST':
#         # Update the survey details based on the form data
#         detailSurvey.question = request.POST.get('question')
#         detailSurvey.response_option1 = request.POST.get('response_option1')
#         detailSurvey.response_option2 = request.POST.get('response_option2')
#         detailSurvey.response_option3 = request.POST.get('response_option3')
#         detailSurvey.response_option4 = request.POST.get('response_option4')
#         # detailSurvey.survey_type = request.POST.get('survey_type')
#         # subUpdateSurvey.survey_question.save()
#         subUpdateSurvey.save()

#         return redirect('surveyList')

#     return render(request, 's_survey/survey_question.html', {'detailSurvey': detailSurvey})